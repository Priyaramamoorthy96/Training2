export const variables = {
    FileServiceUploadFile: {
        _id: "wm-FileServiceUploadFile-wm.ServiceVariable-1554906896143",
        name: "FileServiceUploadFile",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "files",
                value: "bind:Widgets.fileupload1.selectedFiles",
                type: "java.lang.String"
            }
        ],
        type: "com.readthefile.fileservice.FileService.FileUploadResponse",
        service: "FileService",
        operation: "uploadFile",
        operationId: "FileController_uploadFile",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: false,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "File"
    },
    FileServiceUploadFile1: {
        _id: "wm-FileServiceUploadFile1-wm.ServiceVariable-1554906912441",
        name: "FileServiceUploadFile1",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "files",
                value: "bind:Widgets.fileupload2.selectedFiles",
                type: "java.lang.String"
            }
        ],
        type: "com.readthefile.fileservice.FileService.FileUploadResponse",
        service: "FileService",
        operation: "uploadFile",
        operationId: "FileController_uploadFile",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: false,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "File"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
