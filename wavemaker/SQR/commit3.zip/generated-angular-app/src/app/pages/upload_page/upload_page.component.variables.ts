export const variables = {
    FileServiceUploadFile: {
        _id: "wm-FileServiceUploadFile-wm.ServiceVariable-1554905291275",
        name: "FileServiceUploadFile",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "files",
                value: "bind:Widgets.fileupload1.selectedFiles",
                type: "java.lang.String"
            }
        ],
        type: "com.readthefile.fileservice.FileService.FileUploadResponse",
        service: "FileService",
        operation: "uploadFile",
        operationId: "FileController_uploadFile",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: false,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "File"
    },
    insertintodb: {
        _id: "wm-insertintodb-wm.LiveVariable-1554905444872",
        name: "insertintodb",
        owner: "Page",
        category: "wm.LiveVariable",
        dataBinding: [
            {
                target: "filename",
                value: "bind:Widgets.fileupload1.selectedFiles[$i].name",
                type: "string"
            },
            {
                target: "filecontent",
                value: "bind:Widgets.fileupload1.selectedFiles[$i].type",
                type: "blob"
            }
        ],
        operation: "insert",
        dataSet: [],
        type: "Fileinfo",
        isList: false,
        saveInPhonegap: false,
        maxResults: 20,
        designMaxResults: 10,
        inFlightBehavior: "executeLast",
        startUpdate: false,
        autoUpdate: false,
        transformationRequired: false,
        liveSource: "sqrfiles",
        ignoreCase: true,
        matchMode: "startignorecase",
        orderBy: "id asc",
        propertiesMap: {
            columns: [
                {
                    fieldName: "id",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "ID",
                    isPrimaryKey: true,
                    notNull: true,
                    length: 0,
                    precision: 10,
                    generator: "identity",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "filename",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "filename",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "filecontent",
                    type: "blob",
                    fullyQualifiedType: "blob",
                    columnName: "filecontent",
                    isPrimaryKey: false,
                    notNull: false,
                    length: -1,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                }
            ],
            entityName: "Fileinfo",
            fullyQualifiedName: "com.readthefile.sqrfiles.Fileinfo",
            tableType: "TABLE",
            primaryFields: ["id"]
        },
        tableName: "fileinfo",
        tableType: "TABLE",
        properties: [],
        relatedTables: [],
        filterFields: {},
        filterExpressions: {},
        inputFields: {},
        package: "com.readthefile.sqrfiles.Fileinfo"
    },
    SqrfilesFileinfoData: {
        _id: "wm-SqrfilesFileinfoData-wm.LiveVariable-1554905889459",
        name: "SqrfilesFileinfoData",
        owner: "Page",
        category: "wm.LiveVariable",
        dataBinding: [],
        operation: "read",
        dataSet: [],
        type: "Fileinfo",
        isList: true,
        saveInPhonegap: false,
        maxResults: 20,
        designMaxResults: 10,
        inFlightBehavior: "executeLast",
        startUpdate: true,
        autoUpdate: true,
        transformationRequired: false,
        liveSource: "sqrfiles",
        ignoreCase: true,
        matchMode: "startignorecase",
        orderBy: "id asc",
        propertiesMap: {
            columns: [
                {
                    fieldName: "id",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "ID",
                    isPrimaryKey: true,
                    notNull: true,
                    length: 0,
                    precision: 10,
                    generator: "identity",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "filename",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "filename",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "filecontent",
                    type: "blob",
                    fullyQualifiedType: "blob",
                    columnName: "filecontent",
                    isPrimaryKey: false,
                    notNull: false,
                    length: -1,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                }
            ],
            entityName: "Fileinfo",
            fullyQualifiedName: "com.readthefile.sqrfiles.Fileinfo",
            tableType: "TABLE",
            primaryFields: ["id"]
        },
        isDefault: true,
        bindCount: 1,
        tableName: "fileinfo",
        tableType: "TABLE",
        properties: [],
        relatedTables: [],
        filterExpressions: {},
        package: "com.readthefile.sqrfiles.Fileinfo"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
