import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './databasepage.component.script';
import { getVariables } from './databasepage.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-databasepage',
    templateUrl: './databasepage.component.html',
    styleUrls: ['./databasepage.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: DatabasepageComponent
        }
    ]
})
export class DatabasepageComponent extends BasePageComponent {

    pageName = 'databasepage';

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
