export const variables = {
    fileinfo: {
        _id: "wm-fileinfo-wm.LiveVariable-1554092280780",
        name: "fileinfo",
        owner: "Page",
        category: "wm.LiveVariable",
        dataBinding: [
            {
                target: "filename",
                value: "bind:Widgets.fileupload1.selectedFiles[$i].name",
                type: "string"
            },
            {
                target: "filecontent",
                value: "bind:Widgets.textarea1.datavalue",
                type: "blob"
            }
        ],
        operation: "insert",
        dataSet: [],
        type: "Fileinfo",
        isList: false,
        saveInPhonegap: false,
        maxResults: 20,
        designMaxResults: 10,
        inFlightBehavior: "executeLast",
        startUpdate: false,
        autoUpdate: false,
        transformationRequired: false,
        liveSource: "sqrfiles",
        ignoreCase: true,
        matchMode: "startignorecase",
        orderBy: "id asc",
        propertiesMap: {
            columns: [
                {
                    fieldName: "id",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "ID",
                    isPrimaryKey: true,
                    notNull: true,
                    length: 0,
                    precision: 10,
                    generator: "identity",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "filename",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "filename",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "filecontent",
                    type: "blob",
                    fullyQualifiedType: "blob",
                    columnName: "filecontent",
                    isPrimaryKey: false,
                    notNull: false,
                    length: -1,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                }
            ],
            entityName: "Fileinfo",
            fullyQualifiedName: "com.readthefile.sqrfiles.Fileinfo",
            tableType: "TABLE",
            primaryFields: ["id"]
        },
        tableName: "fileinfo",
        tableType: "TABLE",
        properties: [],
        relatedTables: [],
        filterFields: {},
        filterExpressions: {},
        inputFields: {},
        package: "com.readthefile.sqrfiles.Fileinfo"
    },
    FileServiceSampleJavaOperation: {
        _id:
            "wm-FileServiceSampleJavaOperation-wm.ServiceVariable-1554971891773",
        name: "FileServiceSampleJavaOperation",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [],
        type: "string",
        service: "FileService",
        operation: "sampleJavaOperation",
        operationId: "FileController_sampleJavaOperation",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "File"
    },
    FileServiceUploadFile: {
        _id: "wm-FileServiceUploadFile-wm.ServiceVariable-1553852777474",
        name: "FileServiceUploadFile",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "files",
                value: "bind:Widgets.fileupload1.selectedFiles",
                type: "java.lang.String"
            }
        ],
        type: "com.readthefile.fileservice.FileService.FileUploadResponse",
        service: "FileService",
        operation: "uploadFile",
        operationId: "FileController_uploadFile",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: false,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "File"
    },
    newfile: {
        _id: "wm-newfile-wm.ServiceVariable-1554108245859",
        name: "newfile",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "file",
                value: "bind:Widgets.fileupload1.selectedFiles[$i].name",
                type: "string"
            }
        ],
        type: "string",
        service: "FileService",
        operation: "newfilecontent",
        operationId: "FileController_newfilecontent",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "File"
    },
    readthefile: {
        _id: "wm-readthefile-wm.ServiceVariable-1553852905147",
        name: "readthefile",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "file",
                value: "bind:Widgets.fileupload1.selectedFiles[$i].name",
                type: "string"
            }
        ],
        type: "string",
        service: "FileService",
        operation: "sampleJavaOperation",
        operationId: "FileController_sampleJavaOperation",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        onSuccess: "readthefileonSuccess(variable, data, options)",
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "File"
    },
    storedb: {
        _id: "wm-storedb-wm.LiveVariable-1554907389168",
        name: "storedb",
        owner: "Page",
        category: "wm.LiveVariable",
        dataBinding: [
            {
                target: "filename",
                value: "bind:Widgets.fileupload1.selectedFiles[$i].name",
                type: "string"
            }
        ],
        operation: "insert",
        dataSet: [],
        type: "Fileinfo",
        isList: false,
        saveInPhonegap: false,
        maxResults: 20,
        designMaxResults: 10,
        inFlightBehavior: "executeLast",
        startUpdate: false,
        autoUpdate: false,
        transformationRequired: false,
        liveSource: "sqrfiles",
        ignoreCase: true,
        matchMode: "startignorecase",
        orderBy: "id asc",
        propertiesMap: {
            columns: [
                {
                    fieldName: "id",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "ID",
                    isPrimaryKey: true,
                    notNull: true,
                    length: 0,
                    precision: 10,
                    generator: "identity",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "filename",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "filename",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "filecontent",
                    type: "blob",
                    fullyQualifiedType: "blob",
                    columnName: "filecontent",
                    isPrimaryKey: false,
                    notNull: false,
                    length: -1,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    scale: 0
                }
            ],
            entityName: "Fileinfo",
            fullyQualifiedName: "com.readthefile.sqrfiles.Fileinfo",
            tableType: "TABLE",
            primaryFields: ["id"]
        },
        tableName: "fileinfo",
        tableType: "TABLE",
        properties: [],
        relatedTables: [],
        filterFields: {},
        filterExpressions: {},
        inputFields: {},
        package: "com.readthefile.sqrfiles.Fileinfo"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
