import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';

import { ComponentType, RuntimeBaseModule } from '@wm/runtime/base';

import { ComponentRefProviderService } from '../framework/services/component-ref-provider.service';

import { BulkuploadpageComponent } from './pages/Bulkuploadpage/Bulkuploadpage.component';
import { LoginComponent } from './pages/Login/Login.component';
import { MainComponent } from './pages/Main/Main.component';
import { DatabasepageComponent } from './pages/databasepage/databasepage.component';
import { DatatableComponent } from './pages/datatable/datatable.component';
import { Upload_pageComponent } from './pages/upload_page/upload_page.component';

import { CommonComponent } from './partials/Common/Common.component';
import { FooterComponent } from './partials/footer/footer.component';
import { HeaderComponent } from './partials/header/header.component';
import { LeftnavComponent } from './partials/leftnav/leftnav.component';
import { RightnavComponent } from './partials/rightnav/rightnav.component';
import { TopnavComponent } from './partials/topnav/topnav.component';



import initPrefabConfig from './prefabs/prefab-config';

const components = [
    BulkuploadpageComponent,
	CommonComponent,
	LoginComponent,
	MainComponent,
	DatabasepageComponent,
	DatatableComponent,
	FooterComponent,
	HeaderComponent,
	LeftnavComponent,
	RightnavComponent,
	TopnavComponent,
	Upload_pageComponent
];

export const xsrfHeaderName = 'X-WM-XSRF-TOKEN';

@NgModule({
    declarations: components,
    imports: [
        RuntimeBaseModule
    ],
    exports: components,
    entryComponents: components,
    schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class AppCodeGenModule {

}

ComponentRefProviderService.registerComponentRef('Bulkuploadpage', ComponentType.PAGE, BulkuploadpageComponent);
ComponentRefProviderService.registerComponentRef('Common', ComponentType.PARTIAL, CommonComponent);
ComponentRefProviderService.registerComponentRef('Login', ComponentType.PAGE, LoginComponent);
ComponentRefProviderService.registerComponentRef('Main', ComponentType.PAGE, MainComponent);
ComponentRefProviderService.registerComponentRef('databasepage', ComponentType.PAGE, DatabasepageComponent);
ComponentRefProviderService.registerComponentRef('datatable', ComponentType.PAGE, DatatableComponent);
ComponentRefProviderService.registerComponentRef('footer', ComponentType.PARTIAL, FooterComponent);
ComponentRefProviderService.registerComponentRef('header', ComponentType.PARTIAL, HeaderComponent);
ComponentRefProviderService.registerComponentRef('leftnav', ComponentType.PARTIAL, LeftnavComponent);
ComponentRefProviderService.registerComponentRef('rightnav', ComponentType.PARTIAL, RightnavComponent);
ComponentRefProviderService.registerComponentRef('topnav', ComponentType.PARTIAL, TopnavComponent);
ComponentRefProviderService.registerComponentRef('upload_page', ComponentType.PAGE, Upload_pageComponent);

initPrefabConfig();
