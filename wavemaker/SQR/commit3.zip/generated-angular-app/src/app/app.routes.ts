import { Routes } from "@angular/router"

import {
    AppJSResolve,
    AppVariablesResolve,
    AuthGuard,
    MetadataResolve,
    RoleGuard,
    SecurityConfigResolve,
    EmptyPageComponent,
    PageNotFoundGaurd
} from "@wm/runtime/base"

import { BulkuploadpageComponent } from "./pages/Bulkuploadpage/Bulkuploadpage.component"
import { LoginComponent } from "./pages/Login/Login.component"
import { MainComponent } from "./pages/Main/Main.component"
import { DatabasepageComponent } from "./pages/databasepage/databasepage.component"
import { DatatableComponent } from "./pages/datatable/datatable.component"
import { Upload_pageComponent } from "./pages/upload_page/upload_page.component"

const appDependenciesResolve = {
    metadata: MetadataResolve,
    appJS: AppJSResolve,
    appVariables: AppVariablesResolve,
    securityConfig: SecurityConfigResolve
}

export const routes: Routes = [
    {
        path: "",
        pathMatch: "full",
        component: EmptyPageComponent
    },
    {
        path: "",
        resolve: appDependenciesResolve,
        children: [
            {
                path: "Bulkuploadpage",
                pathMatch: "full",
                component: BulkuploadpageComponent
            },
            {
                path: "Login",
                pathMatch: "full",
                component: LoginComponent
            },
            {
                path: "Main",
                pathMatch: "full",
                component: MainComponent
            },
            {
                path: "databasepage",
                pathMatch: "full",
                component: DatabasepageComponent
            },
            {
                path: "datatable",
                pathMatch: "full",
                component: DatatableComponent
            },
            {
                path: "upload_page",
                pathMatch: "full",
                component: Upload_pageComponent
            }
        ]
    },
    {
        path: "**",
        canActivate: [PageNotFoundGaurd],
        component: EmptyPageComponent
    }
]
