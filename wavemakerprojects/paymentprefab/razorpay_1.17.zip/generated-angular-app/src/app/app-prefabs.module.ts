import { CUSTOM_ELEMENTS_SCHEMA, NgModule, NO_ERRORS_SCHEMA } from '@angular/core';

import { ComponentType, RuntimeBaseModule } from '@wm/runtime/base';

import { ComponentRefProviderService } from '../framework/services/component-ref-provider.service';

import { MainComponent as __self__Component } from './prefabs/__self__/Main/Main.component';

import initPrefabConfig from './prefabs/prefab-config';

const components = [
    __self__Component
];

export const xsrfHeaderName = 'X-WM-XSRF-TOKEN';

@NgModule({
    declarations: components,
    imports: [
        RuntimeBaseModule
    ],
    exports: [components, RuntimeBaseModule],
    entryComponents: components,
    schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA]
})
export class AppPrefabsModule {

}

ComponentRefProviderService.registerComponentRef('__self__', ComponentType.PREFAB, __self__Component, null);

initPrefabConfig();
