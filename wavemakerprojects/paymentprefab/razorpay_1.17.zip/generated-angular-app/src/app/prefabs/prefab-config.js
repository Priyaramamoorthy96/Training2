import { registerPrefabConfig } from '../../framework/util/page-util';

export default () => {};

registerPrefabConfig('__self__', {
  "displayName" : "paymentgateway",
  "group" : "",
  "iconUrl" : "/resources/images/imagelists/prefab-icon.png",
  "resources" : {
    "styles" : [ "/pages/Main/Main.css" ],
    "scripts" : [ "/resources/javascript/checkout.js", "/resources/javascript/dropin.min.js", "/resources/javascript/jquery-3.2.1.min.js", "/resources/javascript/pay.js" ]
  },
  "properties" : { },
  "events" : { },
  "methods" : { }
})