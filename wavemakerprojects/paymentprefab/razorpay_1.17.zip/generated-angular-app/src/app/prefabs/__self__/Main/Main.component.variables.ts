export const variables = {
    supportedLocale: {
        _id: "wm-wm.Variable1402640443182",
        name: "supportedLocale",
        owner: "Page",
        category: "wm.Variable",
        dataSet: {
            en: "English"
        },
        type: "string",
        isList: false,
        saveInPhonegap: false
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
