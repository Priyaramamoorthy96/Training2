export const initScript = (Prefab, App, Utils) => {
    /*
     * Use App.getDependency for Dependency Injection
     * eg: var DialogService = App.getDependency('DialogService');
     */

    /*
     * This function will be invoked when any of this Prefab's property is changed
     * @key: property name
     * @newVal: new value of the property
     * @oldVal: old value of the property
     */

    Prefab.onPropertyChange = function(key, newVal, oldVal) {
        /*
        switch (key) {
            case "prop1":
                // do something with newVal for property 'prop1'
                break;
            case "prop2":
                // do something with newVal for property 'prop2'
                break;
        }
        */
    };
    /*
     * Use App.getDependency for Dependency Injection
     * eg: var DialogService = App.getDependency('DialogService');
     */

    /* perform any action on widgets/variables within this block */
    Prefab.onReady = function() {
        $("#rzp-button1").hide();
        $("#razorpay-amt").hide();

    }


    Prefab.button4Click = function($event, widget) {
        $("#rzp-button1").show();
        $("#razorpay-amt").show();

    };

    Prefab.button2Click = function($event, widget) {
        var options = {
            "key": "rzp_test_iUunvOnZtA1FcE",
            "amount": (Prefab.Widgets.text2.datavalue) * 100,
            "name": "",
            "description": "",
            "image": "",
            "handler": function(response) {
                alert(response.razorpay_payment_id);
            },
            "prefill": {
                "name": "",
                "email": ""
            },
            "notes": {
                "address": ""
            },
            "theme": {
                "color": "#F37254"
            }
        };
        var rzp1 = new Razorpay(options);

        rzp1.open();
    };
}