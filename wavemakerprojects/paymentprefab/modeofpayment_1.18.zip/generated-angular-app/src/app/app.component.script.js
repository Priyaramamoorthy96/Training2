export const initScript = (App, Utils, Injector) => {
    
}
