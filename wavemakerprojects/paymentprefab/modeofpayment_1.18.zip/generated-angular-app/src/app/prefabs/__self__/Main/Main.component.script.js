export const initScript = (Prefab, App, Utils) => {
    /*
     * Use App.getDependency for Dependency Injection
     * eg: var DialogService = App.getDependency('DialogService');
     */

    /*
     * This function will be invoked when any of this Prefab's property is changed
     * @key: property name
     * @newVal: new value of the property
     * @oldVal: old value of the property
     */

    Prefab.onPropertyChange = function(key, newVal, oldVal) {
        /*
        switch (key) {
            case "prop1":
                // do something with newVal for property 'prop1'
                break;
            case "prop2":
                // do something with newVal for property 'prop2'
                break;
        }
        */
    };
    /*
     * Use App.getDependency for Dependency Injection
     * eg: var DialogService = App.getDependency('DialogService');
     */

    /* perform any action on widgets/variables within this block */
    Prefab.onReady = function() {
        $("#rzp-button1").hide();
        $("#dropin-container").hide();
        $("#card-purchase").hide();
        $("#razorpay-amt").hide();
    }



    Prefab.button4Click = function($event, widget) {
        $("#rzp-button1").show();
        $("#dropin-container").hide();
        $("#card-purchase").hide();
        $("#razorpay-amt").show();
    };
    Prefab.button3Click = function($event, widget) {
        $("#rzp-button1").hide();
        $("#dropin-container").show();
        $("#card-purchase").show();
        $("#razorpay-amt").hide();
    };

    Prefab.button2Click = function($event, widget) {
        var options = {
            "key": "rzp_test_iUunvOnZtA1FcE",
            "amount": (Prefab.Widgets.text2.datavalue) * 100,
            "name": "",
            "description": "",
            "image": "",
            "handler": function(response) {
                alert(response.razorpay_payment_id);
            },
            "prefill": {
                "name": "",
                "email": ""
            },
            "notes": {
                "address": ""
            },
            "theme": {
                "color": "#F37254"
            }
        };
        var rzp1 = new Razorpay(options);

        rzp1.open();
    };



    const baseRequest = {
        apiVersion: 2,
        apiVersionMinor: 0
    };
    const tokenizationSpecification = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            'gateway': 'example',
            'gatewayMerchantId': 'exampleGatewayMerchantId'
        }
    };
    const allowedCardNetworks = ["AMEX", "DISCOVER", "INTERAC", "JCB", "MASTERCARD", "VISA"];
    const allowedCardAuthMethods = ["PAN_ONLY", "CRYPTOGRAM_3DS"];
    const baseCardPaymentMethod = {
        type: 'CARD',
        parameters: {
            allowedAuthMethods: allowedCardAuthMethods,
            allowedCardNetworks: allowedCardNetworks
        }
    };
    const cardPaymentMethod = Object.assign({
            tokenizationSpecification: tokenizationSpecification
        },
        baseCardPaymentMethod
    );
    const paymentsClient =
        new google.payments.api.PaymentsClient({
            environment: 'TEST'
        });
    const isReadyToPayRequest = Object.assign({}, baseRequest);
    isReadyToPayRequest.allowedPaymentMethods = [baseCardPaymentMethod];


    Prefab.samplePaymentonSuccess = function(variable, data) {
        var button = document.querySelector('#submit-button');

        braintree.dropin.create({
            authorization: Prefab.Variables.samplePayment.dataSet.value,
            container: '#dropin-container',
            paypal: {
                flow: 'vault'
            },
            googlePay: {
                googlePayVersion: 2,
                transactionInfo: {
                    totalPriceStatus: 'FINAL',
                    totalPrice: '123.45',
                    currencyCode: 'USD'
                }
            }
        }, function(err, instance) {

            button.addEventListener('click', function() {
                instance.requestPaymentMethod(function(err, payload) {
                    Prefab.Widgets.label2.caption = payload.nonce;
                });
            });

        });
    }
}