export const initScript = (Page, App, Utils) => {
    /*
     * Use App.getDependency for Dependency Injection
     * eg: var DialogService = App.getDependency('DialogService');
     */

    /*
     * This function will be invoked when any of this Prefab's property is changed
     * @key: property name
     * @newVal: new value of the property
     * @oldVal: old value of the property
     */

    Prefab.onPropertyChange = function(key, newVal, oldVal) {
        /*
        switch (key) {
            case "prop1":
                // do something with newVal for property 'prop1'
                break;
            case "prop2":
                // do something with newVal for property 'prop2'
                break;
        }
        */
    };
    /*
     * Use App.getDependency for Dependency Injection
     * eg: var DialogService = App.getDependency('DialogService');
     */

    /* perform any action on widgets/variables within this block */
    Prefab.onReady = function() {

        $("#dropin-container").hide();
        $("#card-purchase").hide();
        $("#Amount").hide();
    }

    Prefab.button3Click = function($event, widget) {

        $("#dropin-container").show();
        $("#card-purchase").show();
        $("#Amount").show();
    };



    const baseRequest = {
        apiVersion: 2,
        apiVersionMinor: 0
    };
    const tokenizationSpecification = {
        type: 'PAYMENT_GATEWAY',
        parameters: {
            'gateway': 'example',
            'gatewayMerchantId': 'exampleGatewayMerchantId'
        }
    };
    const allowedCardNetworks = ["AMEX", "DISCOVER", "INTERAC", "JCB", "MASTERCARD", "VISA"];
    const allowedCardAuthMethods = ["PAN_ONLY", "CRYPTOGRAM_3DS"];
    const baseCardPaymentMethod = {
        type: 'CARD',
        parameters: {
            allowedAuthMethods: allowedCardAuthMethods,
            allowedCardNetworks: allowedCardNetworks
        }
    };
    const cardPaymentMethod = Object.assign({
            tokenizationSpecification: tokenizationSpecification
        },
        baseCardPaymentMethod
    );
    const paymentsClient =
        new google.payments.api.PaymentsClient({
            environment: 'TEST'
        });
    const isReadyToPayRequest = Object.assign({}, baseRequest);
    isReadyToPayRequest.allowedPaymentMethods = [baseCardPaymentMethod];


    Prefab.samplePaymentonSuccess = function(variable, data) {
        var button = document.querySelector('#submit-button');

        braintree.dropin.create({
            authorization: Prefab.Variables.samplePayment.dataSet.value,
            container: '#dropin-container',
            paypal: {
                flow: 'vault'
            },
            googlePay: {
                googlePayVersion: 2,
                transactionInfo: {
                    totalPriceStatus: 'FINAL',
                    totalPrice: '123.45',
                    currencyCode: 'USD'
                }
            }
        }, function(err, instance) {

            button.addEventListener('click', function() {
                instance.requestPaymentMethod(function(err, payload) {
                    Prefab.Widgets.label2.caption = payload.nonce;
                });
            });

        });
    }
}