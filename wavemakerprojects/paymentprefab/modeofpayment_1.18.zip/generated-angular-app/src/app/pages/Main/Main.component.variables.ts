export const variables = {
    samplePayment: {
        _id: "wm-samplepayment-wm.ServiceVariable-1559893240973",
        name: "samplePayment",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [],
        type: "string",
        service: "MyJavaService",
        operation: "samplePaymentGateway",
        operationId: "MyJavaController_samplePaymentGateway",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        onSuccess: "samplePaymentonSuccess(variable, data, options)",
        startUpdate: true,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "MyJava"
    },
    sampletransaction: {
        _id: "wm-sampletransaction-wm.ServiceVariable-1559893274651",
        name: "sampletransaction",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "nonce",
                value: "bind:Widgets.label2.caption",
                type: "string"
            },
            {
                target: "amount",
                value: "bind:Widgets.test.datavalue",
                type: "string"
            },
            {
                target: "merchant_account",
                value: "bind:Widgets.select1.displayValue",
                type: "string"
            }
        ],
        type: "boolean",
        service: "MyJavaService",
        operation: "transaction",
        operationId: "MyJavaController_transaction",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "MyJava"
    },
    supportedLocale: {
        _id: "wm-wm.Variable1402640443182",
        name: "supportedLocale",
        owner: "Page",
        category: "wm.Variable",
        dataSet: {
            en: "English"
        },
        type: "string",
        isList: false,
        saveInPhonegap: false
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
