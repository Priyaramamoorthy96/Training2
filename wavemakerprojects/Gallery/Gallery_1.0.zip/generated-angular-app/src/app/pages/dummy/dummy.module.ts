import { NgModule } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AppCodeGenModule } from '../../app-codegen.module';

import { HeaderModule } from '../../partials/header/header.module';
import { TopnavModule } from '../../partials/topnav/topnav.module';
import { LeftnavModule } from '../../partials/leftnav/leftnav.module';
import { FooterModule } from '../../partials/footer/footer.module';

import { DummyComponent } from './dummy.component';

const components = [DummyComponent];

const routes: Routes = [
    {
        path: '',
        component: DummyComponent
    }
];

const requiredComponentModules = [
    HeaderModule,
	TopnavModule,
	LeftnavModule,
	FooterModule
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        RouterModule.forChild(routes),
        CommonModule,
        AppCodeGenModule
    ],
    exports: components
})
export class DummyModule {

}

