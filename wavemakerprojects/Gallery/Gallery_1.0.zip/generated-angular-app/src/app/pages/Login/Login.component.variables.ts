export const variables = {
    navToSignUp: {
        _id: "wm-navToSignUp-wm.NavigationVariable-1559113550947",
        name: "navToSignUp",
        owner: "Page",
        category: "wm.NavigationVariable",
        dataBinding: [
            {
                target: "pageName",
                value: "sign_up",
                type: "string"
            }
        ],
        operation: "gotoPage",
        dataSet: [],
        pageTransitions: "none"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
