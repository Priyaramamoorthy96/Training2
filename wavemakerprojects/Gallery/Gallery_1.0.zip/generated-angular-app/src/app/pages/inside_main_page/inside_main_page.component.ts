import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './inside_main_page.component.script';
import { getVariables } from './inside_main_page.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-inside_main_page',
    templateUrl: './inside_main_page.component.html',
    styleUrls: ['./inside_main_page.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: Inside_main_pageComponent
        }
    ]
})
export class Inside_main_pageComponent extends BasePageComponent {

    pageName = 'inside_main_page';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
