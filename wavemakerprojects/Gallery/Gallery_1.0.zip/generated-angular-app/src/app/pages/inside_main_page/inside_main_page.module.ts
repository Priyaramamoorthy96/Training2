import { NgModule } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AppCodeGenModule } from '../../app-codegen.module';

import { HeaderModule } from '../../partials/header/header.module';
import { TopnavModule } from '../../partials/topnav/topnav.module';
import { LeftnavModule } from '../../partials/leftnav/leftnav.module';
import { FooterModule } from '../../partials/footer/footer.module';

import { Inside_main_pageComponent } from './inside_main_page.component';

const components = [Inside_main_pageComponent];

const routes: Routes = [
    {
        path: '',
        component: Inside_main_pageComponent
    }
];

const requiredComponentModules = [
    HeaderModule,
	TopnavModule,
	LeftnavModule,
	FooterModule
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        RouterModule.forChild(routes),
        CommonModule,
        AppCodeGenModule
    ],
    exports: components
})
export class Inside_main_pageModule {

}

