export const variables = {
    FileServiceUploadFile: {
        _id: "wm-FileServiceUploadFile-wm.ServiceVariable-1558952452263",
        name: "FileServiceUploadFile",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                isList: true,
                target: "files",
                value: "bind:Widgets.fileupload1.selectedFiles",
                type: "file"
            }
        ],
        type: "com.gallery.fileservice.FileService.FileUploadResponse",
        service: "FileService",
        operation: "uploadFile",
        operationId: "FileController_uploadFile",
        operationType: "post",
        serviceType: "JavaService",
        dataSet: [],
        isList: true,
        maxResults: 20,
        onSuccess: "Actions.goToLoginPage.invoke()",
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "File"
    },
    insertInto_userDetails: {
        _id: "wm-insertInto_userDetails-wm.LiveVariable-1558960302294",
        name: "insertInto_userDetails",
        owner: "Page",
        category: "wm.LiveVariable",
        dataBinding: [
            {
                target: "userName",
                value: "bind:Widgets.text1.datavalue",
                type: "string"
            },
            {
                target: "password",
                value: "bind:Widgets.text2.datavalue",
                type: "string"
            },
            {
                target: "mail",
                value: "bind:Widgets.text3.datavalue",
                type: "string"
            },
            {
                target: "imagePath",
                value: "bind:Variables.FileServiceUploadFile.dataSet[$i].path",
                type: "string"
            }
        ],
        operation: "insert",
        dataSet: [],
        type: "UserDetails",
        isList: false,
        saveInPhonegap: false,
        maxResults: 20,
        designMaxResults: 10,
        inFlightBehavior: "executeLast",
        startUpdate: false,
        autoUpdate: false,
        transformationRequired: false,
        liveSource: "GalleryDB",
        ignoreCase: true,
        matchMode: "startignorecase",
        orderBy: "id asc",
        propertiesMap: {
            columns: [
                {
                    fieldName: "id",
                    type: "integer",
                    fullyQualifiedType: "integer",
                    columnName: "ID",
                    isPrimaryKey: true,
                    notNull: true,
                    length: 0,
                    precision: 10,
                    generator: "identity",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "userName",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "user_name",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "password",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "password",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "mail",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "mail",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "imagePath",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "image_path",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                },
                {
                    fieldName: "role",
                    type: "string",
                    fullyQualifiedType: "string",
                    columnName: "role",
                    isPrimaryKey: false,
                    notNull: false,
                    length: 255,
                    precision: 0,
                    generator: "assigned",
                    isRelated: false,
                    defaultValue: "",
                    scale: 0
                }
            ],
            entityName: "UserDetails",
            fullyQualifiedName: "com.gallery.gallerydb.UserDetails",
            tableType: "TABLE",
            primaryFields: ["id"]
        },
        tableName: "user_details",
        tableType: "TABLE",
        properties: [],
        relatedTables: [],
        filterFields: {},
        filterExpressions: {},
        inputFields: {},
        package: "com.gallery.gallerydb.UserDetails"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
