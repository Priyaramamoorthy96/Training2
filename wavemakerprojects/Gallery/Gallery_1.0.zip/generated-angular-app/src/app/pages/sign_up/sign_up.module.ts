import { NgModule } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AppCodeGenModule } from '../../app-codegen.module';

import { HeaderModule } from '../../partials/header/header.module';
import { TopnavModule } from '../../partials/topnav/topnav.module';
import { LeftnavModule } from '../../partials/leftnav/leftnav.module';
import { FooterModule } from '../../partials/footer/footer.module';

import { Sign_upComponent } from './sign_up.component';

const components = [Sign_upComponent];

const routes: Routes = [
    {
        path: '',
        component: Sign_upComponent
    }
];

const requiredComponentModules = [
    HeaderModule,
	TopnavModule,
	LeftnavModule,
	FooterModule
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        RouterModule.forChild(routes),
        CommonModule,
        AppCodeGenModule
    ],
    exports: components
})
export class Sign_upModule {

}

