import { Routes } from "@angular/router"

import {
    AppJSResolve,
    AppVariablesResolve,
    AuthGuard,
    MetadataResolve,
    RoleGuard,
    SecurityConfigResolve,
    EmptyPageComponent,
    PageNotFoundGaurd
} from "@wm/runtime/base"

const appDependenciesResolve = {
    metadata: MetadataResolve,
    appJS: AppJSResolve,
    appVariables: AppVariablesResolve,
    securityConfig: SecurityConfigResolve
}

export const routes: Routes = [
    {
        path: "",
        pathMatch: "full",
        component: EmptyPageComponent,
        resolve: appDependenciesResolve
    },
    {
        path: "",
        resolve: appDependenciesResolve,
        children: [
            {
                path: "Login",
                pathMatch: "full",
                loadChildren: "./pages/Login/Login.module#LoginModule"
            },
            {
                path: "Main",
                pathMatch: "full",
                loadChildren: "./pages/Main/Main.module#MainModule"
            },
            {
                path: "dummy",
                pathMatch: "full",
                loadChildren: "./pages/dummy/dummy.module#DummyModule",
                canActivate: [AuthGuard]
            },
            {
                path: "inside_main_page",
                pathMatch: "full",
                loadChildren:
                    "./pages/inside_main_page/inside_main_page.module#Inside_main_pageModule",
                canActivate: [AuthGuard]
            },
            {
                path: "sign_up",
                pathMatch: "full",
                loadChildren: "./pages/sign_up/sign_up.module#Sign_upModule"
            }
        ]
    },
    {
        path: "**",
        canActivate: [PageNotFoundGaurd],
        component: EmptyPageComponent
    }
]
