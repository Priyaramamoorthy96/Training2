export const variables = {
    navTo_loginPage: {
        _id: "wm-navTo_loginPage-wm.NavigationVariable-1558963161241",
        name: "navTo_loginPage",
        owner: "Page",
        category: "wm.NavigationVariable",
        dataBinding: [
            {
                target: "pageName",
                value: "Login",
                type: "string"
            }
        ],
        operation: "gotoPage",
        dataSet: [],
        pageTransitions: "none"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
