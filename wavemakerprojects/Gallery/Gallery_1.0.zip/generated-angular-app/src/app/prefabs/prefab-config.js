import { registerPrefabConfig } from '../../framework/util/page-util';

export default () => {};

