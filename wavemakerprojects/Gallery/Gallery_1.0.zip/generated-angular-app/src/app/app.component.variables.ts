export const variables = {
  "appNotification" : {
    "_id" : "wm-appErrorHandler-wm.NotificationVariable-1454664620943",
    "name" : "appNotification",
    "owner" : "App",
    "category" : "wm.NotificationVariable",
    "dataBinding" : [ {
      "target" : "class",
      "value" : "Error",
      "type" : "list"
    }, {
      "target" : "toasterPosition",
      "value" : "bottom right",
      "type" : "list"
    } ],
    "operation" : "toast"
  },
  "goToPage_dummy" : {
    "_id" : "wm-goToPage_dummy-wm.NavigationVariable-1559213553927",
    "name" : "goToPage_dummy",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "dummy",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_inside_main_page" : {
    "_id" : "wm-goToPage_inside_main_page-wm.NavigationVariable-1559039503490",
    "name" : "goToPage_inside_main_page",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ ],
    "operation" : "gotoPage",
    "pageName" : "inside_main_page",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "goToPage_Main" : {
    "_id" : "wm-wm.NavigationVariable1389180517517",
    "name" : "goToPage_Main",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "operation" : "gotoPage",
    "pageName" : "Main"
  },
  "goToPage_sign_up" : {
    "_id" : "wm-goToPage_sign_up-wm.NavigationVariable-1558951922192",
    "name" : "goToPage_sign_up",
    "owner" : "App",
    "category" : "wm.NavigationVariable",
    "dataBinding" : [ {
      "target" : "pageName",
      "value" : "sign_up",
      "type" : "string"
    } ],
    "operation" : "gotoPage",
    "pageName" : "sign_up",
    "dataSet" : [ ],
    "pageTransitions" : "none"
  },
  "loggedInUser" : {
    "_id" : "wm-loggedInUser-wm.Variable-1558960038085",
    "name" : "loggedInUser",
    "owner" : "App",
    "category" : "wm.Variable",
    "dataBinding" : [ ],
    "dataSet" : {
      "name" : "",
      "id" : "",
      "tenantId" : "",
      "isAuthenticated" : false,
      "isSecurityEnabled" : true,
      "roles" : [ ]
    },
    "type" : "string",
    "isList" : false,
    "twoWayBinding" : false,
    "saveInPhonegap" : false
  },
  "loginAction" : {
    "_id" : "wm-loginAction-wm.LoginVariable-1558960038084",
    "name" : "loginAction",
    "owner" : "App",
    "category" : "wm.LoginVariable",
    "dataBinding" : [ ],
    "dataSet" : { },
    "type" : "string",
    "saveInPhonegap" : false,
    "startUpdate" : false,
    "autoUpdate" : false,
    "inFlightBehavior" : "executeLast",
    "transformationRequired" : false,
    "useDefaultSuccessHandler" : true
  },
  "logoutAction" : {
    "_id" : "wm-logoutAction-wm.LogoutVariable-1558960038085",
    "name" : "logoutAction",
    "owner" : "App",
    "category" : "wm.LogoutVariable",
    "type" : "string",
    "saveInPhonegap" : false,
    "inFlightBehavior" : "executeLast",
    "transformationRequired" : false,
    "redirectTo" : "Login",
    "useDefaultSuccessHandler" : true
  },
  "supportedLocale" : {
    "_id" : "wm-wm.Variable1402640443182",
    "name" : "supportedLocale",
    "owner" : "App",
    "category" : "wm.Variable",
    "dataSet" : {
      "en" : "English"
    },
    "type" : "string",
    "isList" : false,
    "saveInPhonegap" : false
  }
};

export const getVariables = () => JSON.parse(JSON.stringify(variables));
