/*Copyright (c) 2019-2020 imaginea.com All Rights Reserved.
 This software is the confidential and proprietary information of imaginea.com You shall not disclose such Confidential Information and shall use it only in accordance
 with the terms of the source code license agreement you entered into with imaginea.com*/
package com.payment_gateway_app.myjavaservice;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import com.wavemaker.runtime.security.SecurityService;
import com.wavemaker.runtime.service.annotations.ExposeToClient;
import com.wavemaker.runtime.service.annotations.HideFromClient;

import com.braintreegateway.*;
import java.math.*;
import org.springframework.beans.factory.annotation.Value;

@ExposeToClient
public class MyJavaService {
    private static final Logger logger = LoggerFactory.getLogger(MyJavaService.class);

    @Autowired
    private SecurityService securityService;

    @Value("${app.environment.MerchantId}")
    private String merchant_id;

    @Value("${app.environment.PrivateKey}")
    private String private_key;

    @Value("${app.environment.PublicKey}")
    private String public_key;

    public String samplePaymentGateway() {

        String clientToken = getGateway().clientToken().generate();

        System.out.println("generated client token" + clientToken);
        return clientToken;

    }
    public boolean transaction(String nonce, String amount, String merchant_account) {
        System.out.println("nonce" + nonce);
        if (merchant_account.equals("INR")) {
            merchant_account = "newmcntacctid";
        } else if (merchant_account.equals("AUD")) {
            merchant_account = "r93zxmbnz7sdbpky";
        } else if (merchant_account.equals("USD")) {
            merchant_account = "pramati";
        }

        System.out.println("merchant_account:" + merchant_account);

        TransactionRequest request = new TransactionRequest().amount(new BigDecimal(amount)).merchantAccountId(merchant_account).paymentMethodNonce(nonce).options().submitForSettlement(true).done();

        Result < Transaction > result = getGateway().transaction().sale(request);

        System.out.println(result);
        

        if (result.isSuccess()) {
            System.out.println(result.isSuccess());
            return true;
        } else {
            System.out.println(result.isSuccess());
            return false;
        }
    }

    private BraintreeGateway getGateway() {
        logger.error("getGateway>>>");
        logger.error(merchant_id + " " + private_key + " " + public_key);
        return new BraintreeGateway(
            Environment.SANDBOX,
            merchant_id,
            public_key,
            private_key
        );
    }
}