export const variables = {
    samplePayment: {
        _id: "wm-samplePayment-wm.ServiceVariable-1558699389837",
        name: "samplePayment",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [],
        type: "string",
        service: "MyJavaService",
        operation: "samplePaymentGateway",
        operationId: "MyJavaController_samplePaymentGateway",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        onSuccess: "samplePaymentonSuccess(variable, data, options)",
        startUpdate: true,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "MyJava"
    },
    sampleTransaction: {
        _id: "wm-sampleTransaction-wm.ServiceVariable-1558699440438",
        name: "sampleTransaction",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "nonce",
                value: "bind:Widgets.label2.caption",
                type: "string"
            },
            {
                target: "amount",
                value: "bind:Widgets.text1.datavalue",
                type: "string"
            },
            {
                target: "merchant_account",
                value: "bind:Widgets.select1.datavalue",
                type: "string"
            }
        ],
        type: "boolean",
        service: "MyJavaService",
        operation: "transaction",
        operationId: "MyJavaController_transaction",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "MyJava"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
