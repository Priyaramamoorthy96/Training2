/*
     * This function will be invoked when any of this prefab's property is changed
     * @key: property name
     * @newVal: new value of the property
     * @oldVal: old value of the property
     */

function propertyChangeHandler(key, newVal, oldVal) {
  /*
        switch (key) {
        	case "prop1":
        		// do something with newVal for property 'prop1'
        		break;
        	case "prop2":
        		// do something with newVal for property 'prop2'
        		break;
        }
        */

}
/* register the property change handler */

Prefab.onPropertyChange = propertyChangeHandler;
Prefab.onReady = function() {
  // this method will be triggered post initialization of the prefab.
};
Prefab.emicalc = function() {
  debugger;
  if ((Prefab.loanamount === null || Prefab.loanamount.length === 0) || (Prefab.loantenure === null || Prefab.loantenure.length === 0) || (Prefab.roi === null || Prefab.roi.length === 0)) {
    Prefab.emi = 100;
  } else {
    var princ = Prefab.loanamount;
    var term = Prefab.loantenure;
    var intr = Prefab.roi / 1200;
    Prefab.emi = princ * intr / (1 - (Math.pow(1 / (1 * intr), term)));
  }
};
Prefab.EMIcalcBtnClick = function($event, widget) {
  debugger;
  Prefab.emicalc();
};
// };
