import { Routes } from "@angular/router"

import {
    AppJSResolve,
    AppVariablesResolve,
    AuthGuard,
    MetadataResolve,
    RoleGuard,
    SecurityConfigResolve,
    EmptyPageComponent,
    PageNotFoundGaurd
} from "@wm/runtime/base"

const appDependenciesResolve = {
    metadata: MetadataResolve,
    appJS: AppJSResolve,
    appVariables: AppVariablesResolve,
    securityConfig: SecurityConfigResolve
}

export const routes: Routes = [
    {
        path: "",
        pathMatch: "full",
        component: EmptyPageComponent,
        resolve: appDependenciesResolve
    },
    {
        path: "",
        resolve: appDependenciesResolve,
        children: [
            {
                path: "Bulkuploadpage",
                pathMatch: "full",
                loadChildren:
                    "./pages/Bulkuploadpage/Bulkuploadpage.module#BulkuploadpageModule"
            },
            {
                path: "Login",
                pathMatch: "full",
                loadChildren: "./pages/Login/Login.module#LoginModule"
            },
            {
                path: "Main",
                pathMatch: "full",
                loadChildren: "./pages/Main/Main.module#MainModule"
            },
            {
                path: "databasepage",
                pathMatch: "full",
                loadChildren:
                    "./pages/databasepage/databasepage.module#DatabasepageModule"
            },
            {
                path: "datatable",
                pathMatch: "full",
                loadChildren:
                    "./pages/datatable/datatable.module#DatatableModule"
            },
            {
                path: "upload_page",
                pathMatch: "full",
                loadChildren:
                    "./pages/upload_page/upload_page.module#Upload_pageModule"
            }
        ]
    },
    {
        path: "**",
        canActivate: [PageNotFoundGaurd],
        component: EmptyPageComponent
    }
]
