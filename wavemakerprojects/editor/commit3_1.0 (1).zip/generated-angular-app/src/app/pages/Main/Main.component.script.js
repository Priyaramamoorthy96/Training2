export const initScript = (Page, App, Utils) => {
    /*
     * Use App.getDependency for Dependency Injection
     * eg: var DialogService = App.getDependency('DialogService');
     */

    /* perform any action on widgets/variables within this block */

    Page.onReady = function() {
        /*
         * variables can be accessed through 'Page.Variables' property here
         * e.g. to get dataSet in a staticVariable named 'loggedInUser' use following script
         * Page.Variables.loggedInUser.getData()
         *
         * widgets can be accessed through 'Page.Widgets' property here
         * e.g. to get value of text widget named 'username' use following script
         * 'Page.Widgets.username.datavalue'
         */

    };
    Page.readthefileonSuccess = function(variable, data) {
        var editor = ace.edit("editor");
        editor.setTheme("ace/theme/monokai");
        editor.session.setMode("ace/mode/python");
        editor.setValue(data.value);
        Page.button1Click = function($event, widget) {
            var myCode = editor.getSession().getValue();
            console.log(myCode);
            Page.Widgets.textarea1.datavalue = myCode;
            Page.Variables.editfile.invoke();
        };
    };
}