import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './Bulkuploadpage.component.script';
import { getVariables } from './Bulkuploadpage.component.variables';

import { BasePageComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-page-Bulkuploadpage',
    templateUrl: './Bulkuploadpage.component.html',
    styleUrls: ['./Bulkuploadpage.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: BulkuploadpageComponent
        }
    ]
})
export class BulkuploadpageComponent extends BasePageComponent {

    pageName = 'Bulkuploadpage';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Page, App, Utils) {
        initScript(Page, App, Utils);
    }
}
