import { NgModule } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AppCodeGenModule } from '../../app-codegen.module';

import { HeaderModule } from '../../partials/header/header.module';
import { TopnavModule } from '../../partials/topnav/topnav.module';
import { LeftnavModule } from '../../partials/leftnav/leftnav.module';
import { RightnavModule } from '../../partials/rightnav/rightnav.module';
import { FooterModule } from '../../partials/footer/footer.module';

import { DatabasepageComponent } from './databasepage.component';

const components = [DatabasepageComponent];

const routes: Routes = [
    {
        path: '',
        component: DatabasepageComponent
    }
];

const requiredComponentModules = [
    HeaderModule,
	TopnavModule,
	LeftnavModule,
	RightnavModule,
	FooterModule
];

@NgModule({
    declarations: components,
    imports: [
        ...requiredComponentModules,
        RouterModule.forChild(routes),
        CommonModule,
        AppCodeGenModule
    ],
    exports: components
})
export class DatabasepageModule {

}

