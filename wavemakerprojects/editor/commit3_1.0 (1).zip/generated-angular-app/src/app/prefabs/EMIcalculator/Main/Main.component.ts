import { Component, Injector, ViewEncapsulation } from '@angular/core';

import { UserDefinedExecutionContext } from '@wm/core';

import { initScript } from './Main.component.script';
import { getVariables } from './Main.component.variables';

import { BasePrefabComponent } from '@wm/runtime/base';

@Component({
    selector: 'app-prefab-EMIcalculator',
    templateUrl: './Main.component.html',
    styleUrls: ['./Main.component.css'],
    encapsulation: ViewEncapsulation.None,
    providers: [
        {
            provide: UserDefinedExecutionContext,
            useExisting: MainComponent
        }
    ]
})
export class MainComponent extends BasePrefabComponent {

    prefabName = 'EMIcalculator';
    [key: string]: any;

    constructor(public injector: Injector) {
        super();
        super.init();
    }

    getVariables() {
        return getVariables();
    }

    evalUserScript(Prefab, App, Utils) {
        initScript(Prefab, App, Utils);
    }
}
