import { registerPrefabConfig } from '../../framework/util/page-util';

export default () => {};

registerPrefabConfig('EMIcalculator', {
  "displayName" : "EMIcalculator",
  "group" : "",
  "iconUrl" : "/resources/images/imagelists/prefab-icon.png",
  "resources" : {
    "styles" : [ "/pages/Main/Main.css" ],
    "scripts" : [ ],
    "modules" : [ ]
  },
  "properties" : {
    "loanamount" : {
      "type" : "string",
      "displayName" : "Loanamount",
      "bindable" : "in-bound",
      "value" : "",
      "widget" : "string",
      "show" : true,
      "disabled" : false,
      "description" : ""
    },
    "loantenture" : {
      "type" : "string",
      "displayName" : "Loantenture",
      "bindable" : "in-bound",
      "widget" : "string",
      "show" : true,
      "disabled" : false,
      "description" : "",
      "value" : ""
    },
    "roi" : {
      "type" : "string",
      "displayName" : "Roi",
      "bindable" : "in-bound",
      "widget" : "string",
      "show" : true,
      "disabled" : false,
      "description" : "",
      "value" : ""
    },
    "emi" : {
      "type" : "string",
      "displayName" : "Emi",
      "bindable" : "out-bound",
      "value" : "100",
      "description" : ""
    }
  },
  "methods" : { },
  "events" : { }
})