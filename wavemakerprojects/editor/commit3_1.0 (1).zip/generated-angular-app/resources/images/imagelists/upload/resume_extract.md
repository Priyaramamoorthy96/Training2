### Getting data from CV using Python :
### Task
Convert all the files from the given folder and extract the Technical skills from the files and store the count of language known in the Excel sheet
#### Procedure
  - Find all the files inside the directory.
  - Store filenames in Variable & pass them on for loop with convertor().
  - Create a text file & store the details on it using write().
  - Save all converted file inside a seprete folder.
  - Create a text file with Technical Skil
  - Extract the Technical skills from the files
  - Count the number of languages known
  - Store the file name, MailId, PhoneNumber, all the technical languages along with the count in the Excel sheet
  


