export const variables = {
    downloadtest: {
        _id: "wm-downloadtest-wm.ServiceVariable-1557403386306",
        name: "downloadtest",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "file",
                value: "bind:Widgets.listFilesTable2.selecteditem.name",
                type: "string"
            },
            {
                target: "returnName",
                value: "bind:Widgets.listFilesTable2.selecteditem.name",
                type: "string"
            }
        ],
        type: "com.wavemaker.runtime.file.model.DownloadResponse",
        service: "FileService",
        operation: "getDownloadFileAsInline",
        operationId: "FileController_getDownloadFileAsInline",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "File"
    },
    FileServiceListFiles: {
        _id: "wm-FileServiceListFiles-wm.ServiceVariable-1557391641409",
        name: "FileServiceListFiles",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [],
        type: "com.testing_pdf.fileservice.FileService.WMFile",
        service: "FileService",
        operation: "listFiles",
        operationId: "FileController_listFiles",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: true,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "File"
    },
    FileServiceListFiles1: {
        _id: "wm-FileServiceListFiles1-wm.ServiceVariable-1557391783802",
        name: "FileServiceListFiles1",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [],
        type: "com.testing_pdf.fileservice.FileService.WMFile",
        service: "FileService",
        operation: "listFiles",
        operationId: "FileController_listFiles",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: true,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "File"
    },
    FileServiceUploadFile1: {
        _id: "wm-FileServiceUploadFile1-wm.ServiceVariable-1557391709807",
        name: "FileServiceUploadFile1",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "files",
                value: "bind:Widgets.fileupload2.selectedFiles",
                type: "java.lang.String"
            }
        ],
        type: "com.testing_pdf.fileservice.FileService.FileUploadResponse",
        service: "FileService",
        operation: "uploadFile",
        operationId: "FileController_uploadFile",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: false,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        isDefault: true,
        controller: "File"
    },
    listfiles: {
        _id: "wm-listfiles-wm.ServiceVariable-1557391754160",
        name: "listfiles",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [],
        type: "com.testing_pdf.fileservice.FileService.WMFile",
        service: "FileService",
        operation: "listFiles",
        operationId: "FileController_listFiles",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: true,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "File"
    },
    pdfconvert: {
        _id: "wm-serviceVariable1-wm.ServiceVariable-1557307599688",
        name: "pdfconvert",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "url1",
                value: "bind:Widgets.text1.datavalue",
                type: "string"
            },
            {
                target: "url2",
                value: "bind:Widgets.text2.datavalue",
                type: "string"
            },
            {
                target: "url3",
                value: "bind:Widgets.text3.datavalue",
                type: "string"
            },
            {
                target: "url4",
                value: "bind:Widgets.text4.datavalue",
                type: "string"
            },
            {
                target: "url5",
                value: "bind:Widgets.text5.datavalue",
                type: "string"
            },
            {
                target: "url6",
                value: "bind:Widgets.text6.datavalue",
                type: "string"
            },
            {
                target: "url7",
                value: "bind:Widgets.text7.datavalue",
                type: "string"
            },
            {
                target: "url8",
                value: "bind:Widgets.text8.datavalue",
                type: "string"
            },
            {
                target: "url9",
                value: "bind:Widgets.text9.datavalue",
                type: "string"
            },
            {
                target: "url10",
                value: "bind:Widgets.text10.datavalue",
                type: "string"
            }
        ],
        type: "string",
        service: "MyJavaService",
        operation: "convert",
        operationId: "MyJavaController_convert",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "MyJava"
    },
    stTemp: {
        _id: "wm-stTemp-wm.ServiceVariable-1557404118936",
        name: "stTemp",
        owner: "Page",
        category: "wm.ServiceVariable",
        dataBinding: [
            {
                target: "file",
                value: "bind:Widgets.listFilesTable2.selecteditem.name",
                type: "string"
            },
            {
                target: "returnName",
                value: "bind:Widgets.listFilesTable2.selecteditem.name",
                type: "string"
            }
        ],
        type: "com.wavemaker.runtime.file.model.DownloadResponse",
        service: "FileService",
        operation: "getDownloadFile",
        operationId: "FileController_getDownloadFile",
        operationType: "get",
        serviceType: "JavaService",
        dataSet: [],
        isList: false,
        maxResults: 20,
        startUpdate: false,
        autoUpdate: true,
        inFlightBehavior: "executeLast",
        transformationRequired: false,
        saveInPhonegap: false,
        controller: "File"
    }
}

export const getVariables = () => JSON.parse(JSON.stringify(variables))
